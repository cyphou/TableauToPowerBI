Tableau to Power BI Evidence Package
=====================================

Report: BigQuery_Analytics
Status: WARN
Handoff: WARN

Release readiness: needs_review
Release claim: static_corpus_only

Static evidence and runtime evidence are intentionally separated.
A not_run runtime state is not a deployment or refresh success.
This archive also includes the generated quality artifacts for direct review.
